package com.example.Downstream.Service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DownstreamServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
